<# 
.SYNOPSIS
Export Power BI Premium Gen2 metrics

.DESCRIPTION
The sample scripts are not supported under any Microsoft standard support program or service. 
The sample scripts are provided AS IS without warranty of any kind. 
Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of 
fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the 
sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#>

function Export-PbiPremiumMetrics {
    param(
        [hashtable]$Config
    )

    Write-Host "Exporting Premium utilization..."
    # Export premium specific metrics. this connects to the underlying SSAS database that powers the workspace and exports the data
    # DAX Queries to query against PowerBI. Should not need changed.

    $artifactMetrics = @()
    $artifactMemory = @()

    Write-AssessmentLog "Fabric Capacity Metrics app detected: $($Config.PremiumDatasetId). Exporting..." -Config $Config
    [array]$capacities = Export-PbiPremiumData -DAXQuery "EVALUATE SELECTCOLUMNS(Capacities, Capacities[capacityId])" -Config $Config
    
    $capacities | ForEach-Object {
        $currentCapacityId = $_.'Capacities[capacityId]'
        
        [array]$timestampStats = Export-PbiPremiumData -DAXQuery "DEFINE MPARAMETER CapacityID = ""$currentCapacityId"" 
            EVALUATE FILTER(
                SUMMARIZECOLUMNS(
                    MetricsByItemandOperationandHour[DateTime],
                    ""OperationsCount"", SUM(MetricsByItemandOperationandHour[count_operations])
                ),
            [OperationsCount] > 0)" `
            -Config $Config

        $statIndex = 0
        $continuePaging = $True 
        while ($continuePaging) {
    
            $runningTotal = 0
            $dateList = @()
            while ($True) {
                if ($statIndex -ge $timestampStats.Count) {
                    $continuePaging = $false
                    break;
                }
                $runningTotal += $timestampStats[$statIndex].'[OperationsCount]'
                $dateList += $timestampStats[$statIndex].'MetricsByItemandOperationandHour[DateTime]'.ToString().Replace("T", " ")
                $statIndex += 1
                if ($runningTotal -gt 100000) {
                    break;
                }
            }
            if ($dateList.Count -le 0) {
                break;
            }

            $dateListText = $dateList -join ""","""
            Write-AssessmentLog "Reading capacity $currentCapacityId metrics partition containing $($dateList.Count) timestamps" -Config $Config

            $artifactMetrics += Export-PbiPremiumData -DAXQuery "
                DEFINE MPARAMETER CapacityID = ""$currentCapacityId"" 
                EVALUATE FILTER(
                    SUMMARIZECOLUMNS(
                        Items[ItemKind],
                        Items[ItemId],
                        MetricsByItemandOperationandHour[DateTime],
                        'OperationNames'[OperationName],
                        TREATAS({""$dateListText""}, MetricsByItemandOperationandHour[DateTime]),
                        ""OperationsCount"", SUM(MetricsByItemandOperationandHour[count_operations]),
                        ""UsersCount"",SUM(MetricsByItemandOperationandHour[count_users]),
                        ""CU"", SUM(MetricsByItemandOperationandHour[sum_CU]),
                        ""Duration (ms)"", SUM(MetricsByItemandOperationandHour[sum_duration])
                    ),
                [OperationsCount] > 0)"  -Config $Config

            $artifactMetrics | Select-Object `
            @{Name = "[OperationsCount]"; Expression = { $_."[OperationsCount]" } }, `
            @{Name = "Artifacts[ArtifactKind]"; Expression = { $_."Items[ItemKind]" } }, `
            @{Name = "Artifacts[ArtifactId]"; Expression = { $_."Items[ItemId]"} }, `
            @{Name = "Metrics_by_Artifact_and_Operation_and_Hour[DateTime]"; Expression = { $_."MetricsByItemandOperationandHour[DateTime]" } }, `
            @{Name = "Operation Names[OperationName]"; Expression = { $_."OperationNames[OperationName]" } }, `
            @{Name = "[CU]"; Expression = { $_."[CU]" } }, `
            @{Name = "[UsersCount]"; Expression = { $_."[UsersCount]" } }, `
            @{Name = "[Duration (ms)]"; Expression = { $_."[Duration (ms)]" } } `
            | Add-AssessmentRecords -SinkContainer "PremiumArtifactMetrics" -Config $Config
    
        }

        $artifactMemory += Export-PbiPremiumData -DAXQuery "
            DEFINE MPARAMETER CapacityID = ""$currentCapacityId"" 
            EVALUATE SUMMARIZECOLUMNS(
                'Items'[ItemKind],
                'Items'[ItemId],
                ""MaxMemory"", MAX(MaxMemoryByItem[Item Size (GB)]) * 1024 * 1024 * 1024
                )"  -Config $Config

        $artifactMemory | Select-Object `
        @{Name = "Artifacts[ArtifactKind]"; Expression = { $_."Items[ItemKind]" } }, `
        @{Name = "Artifacts[ArtifactId]"; Expression = { $_."Items[ItemId]"} }, `
        @{Name = "[MaxMemory]"; Expression = { $_."[MaxMemory]" } } `
        | Add-AssessmentRecords -SinkContainer "PremiumArtifactMemory" -Config $Config
    }
}