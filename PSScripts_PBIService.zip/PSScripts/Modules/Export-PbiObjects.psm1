<# 
.SYNOPSIS
Export Power BI Premium Data

.DESCRIPTION
The sample scripts are not supported under any Microsoft standard support program or service. 
The sample scripts are provided AS IS without warranty of any kind. 
Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of 
fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the 
sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#>

function Export-PbiObjects {
    param(
        [hashtable]$Config
    )

    # Export Tenant Name
    Write-AssessmentLog "Exporting Tenant name and home region" -Config $Config
    # if service principal auth then just use the tenant id. 
    if ($Config.ServicePrincipalAuth) {
        $Tenant = New-Object -TypeName PSObject -Property @{TenantDomain = $Config.TenantID }
    }
    else {
        $userUpn = ($Config.AuthContext.UserName, $null -ne $Config.AuthContext.Account.Id)[0]
        $Tenant = New-Object -TypeName PSObject -Property @{TenantDomain = (New-Object MailAddress $userUpn).Host }
    }
    $Tenant | Add-AssessmentRecords -SinkContainer "PowerBITenant" -Config $Config

    if ($Config.ExportEmbedCodes) {
        # Export the embed codes via the Export-PbiEmbedCodes module
        Export-PbiEmbedCodes -Config $Config | Add-AssessmentRecords -SinkContainer "EmbedCodes" -Config $Config
    }
    else {
        Write-AssessmentLog "Export EmbedCodes is False. Skipping..." -Config $Config
    }

    if ($Config.ExportGateways) {
        Export-PbiGateways -Config $Config | Add-AssessmentRecords -SinkContainer "Gateways" -Config $Config
    }
    else {
        Write-AssessmentLog "ExportGateways is False. Skipping..." -Config $Config
    }    
    

    if ($Config.ExportPremiumMetrics) {
        Export-PbiPremiumMetrics -Config $Config
        Export-PbiPremiumCapacities -Config $Config | Add-AssessmentRecords -SinkContainer "PremiumCapacities" -Config $Config
        Export-PbiPremiumScheduledRefresh -Config $Config | Add-AssessmentRecords -SinkContainer "PremiumScheduledRefresh" -Config $Config
    }
    else {
        Write-AssessmentLog "ExportPremiumMetrics is False. Skipping..." -Config $Config
    }

    if ($Config.ExportInventory) {
        if ($Config.DisableScanAPI) {
            Export-PbiInventory -Config $Config
        }
        else {
            Export-PbiInventoryScanAPI -Config $Config
        }
    }
    else {
        Write-AssessmentLog "ExportInventory is False. Skipping..." -Config $Config
    }

    if ($Config.ExportLicenses) {
        Export-PbiLicenses -Config $Config
    }
    else {
        Write-AssessmentLog "ExportLicenses is False. Skipping..." -Config $Config
    }
    
    if ($Config.ExportTenantSettings) {
        Export-PbiTenantSettings -Config $Config | Add-AssessmentRecords -SinkContainer "TenantSettings" -Config $Config
    }
    else {
        Write-AssessmentLog "ExportTenantSettings is False. Skipping..." -Config $Config
    }
}