<# 
.SYNOPSIS
Verify Power BI Assessment Pre-requesites

.DESCRIPTION
The sample scripts are not supported under any Microsoft standard support program or service. 
The sample scripts are provided AS IS without warranty of any kind. 
Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of 
fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the 
sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#>

function Get-Configuration {
    param (
        #Override file path
        [string]$Override
    )

    $Config = @{
        Environment                = "Public"
        AdEnvironment              = "AzureCloud"

        SinkType                   = "CSV"
        Sink                       = "out"
        SinkSchema                 = "dbo"

        AuditLogDays               = 30
        AuditLogBatchHours         = 24

        ThrottleScanAPI            = $false
        DisableScanAPI             = $false
        UseOLAPDatasetConnector    = $false

        ExportPremiumMetrics       = $false
        PremiumDatasetId           = ""

        ExportEmbedCodes           = $false
        ExportGateways             = $true
        ExportActivityLog          = $true
        ExportInventory            = $true
        ExportInventoryExpressions = $false
        ExportRefreshes            = $true 
        ExportV1Users              = $true
        ExportLicenses             = $true
        ExportLicensesProDetail    = $true
        ExportDatasources          = $true
		ExportPipelines         = $true							   
        
        # Service Principal Changes - Begin
        ServicePrincipalAuth       = $false
        ServicePrincipalID         = ""
        ServicePrincipalSecret     = ""
        TenantID                   = ""
        # Service Principal Changes - End

        CredentialsOverride        = $null
        CredentialsOverrideFile    = $null

        AuthContext                = $null
        AuthAdContext              = $null
        AuthMsolContext            = $null
        LogQueries                 = $false

        ApiGatewayUri              = "https://api.powerbi.com"
        ApiResourceUri             = "https://analysis.windows.net"
        ApiFabricUri               = "https://api.fabric.microsoft.com"

        # Define tag for output file or record with DateStamp
        OutputTag                  = (Get-Date).ToString(".yyyyMMdd.HHmm")
    }

    #Read configuration from a file if provided, otherwise - ask
    if ($Override -and (Test-Path $Override)) {
        $conversionError = $null
        $overrideData = Get-Content $Override | ConvertFrom-Json -ErrorVariable conversionError

        if ($conversionError) { 
            Write-Error "ERROR: Configuration file could not be read. Please check file format (JSON)"
            Break Script 
        }

        if ($overrideData) {
            if ($null -ne $overrideData.Environment) { $Config.Environment = $overrideData.Environment }

            if ($null -ne $overrideData.SinkType) { $Config.SinkType = $overrideData.SinkType }
            if ($null -ne $overrideData.Sink) { $Config.Sink = $overrideData.Sink }
            if ($null -ne $overrideData.SinkSchema) { $Config.SinkSchema = $overrideData.SinkSchema }

            if ($null -ne $overrideData.ExportTenantSettings) { $Config.ExportTenantSettings = $overrideData.ExportTenantSettings }
            if ($null -ne $overrideData.ExportEmbedCodes) { $Config.ExportEmbedCodes = $overrideData.ExportEmbedCodes }
            if ($null -ne $overrideData.ExportGateways) { $Config.ExportGateways = $overrideData.ExportGateways }
            if ($null -ne $overrideData.AuditLogDays) { $Config.AuditLogDays = $overrideData.AuditLogDays }
            if ($null -ne $overrideData.AuditLogBatchHours) { $Config.AuditLogBatchHours = $overrideData.AuditLogBatchHours }
            if ($null -ne $overrideData.ExportPremiumMetrics) { $Config.ExportPremiumMetrics = $overrideData.ExportPremiumMetrics }
            if ($null -ne $overrideData.PremiumDatasetId) { $Config.PremiumDatasetId = $overrideData.PremiumDatasetId }
            if ($null -ne $overrideData.ExportActivityLog) { $Config.ExportActivityLog = $overrideData.ExportActivityLog }
            if ($null -ne $overrideData.ExportInventory) { $Config.ExportInventory = $overrideData.ExportInventory }
            if ($null -ne $overrideData.ExportInventoryExpressions) { $Config.ExportInventoryExpressions = $overrideData.ExportInventoryExpressions }
            if ($null -ne $overrideData.ExportRefreshes) { $Config.ExportRefreshes = $overrideData.ExportRefreshes }
            if ($null -ne $overrideData.ExportV1Users) { $Config.ExportV1Users = $overrideData.ExportV1Users }
            if ($null -ne $overrideData.ExportLicenses) { $Config.ExportLicenses = $overrideData.ExportLicenses }
            if ($null -ne $overrideData.ExportLicensesProDetail) { $Config.ExportLicensesProDetail = $overrideData.ExportLicensesProDetail }
            if ($null -ne $overrideData.ExportDatasources) { $Config.ExportDatasources = $overrideData.ExportDatasources }
			if ($null -ne $overrideData.ExportPipelines) { $Config.ExportPipelines = $overrideData.ExportPipelines }																										
            if ($null -ne $overrideData.LogQueries) { $Config.LogQueries = $overrideData.LogQueries }
            
            #Service Principal Changes - Begin
            if ($null -ne $overrideData.ServicePrincipalAuth) { $Config.ServicePrincipalAuth = $overrideData.ServicePrincipalAuth }
            if ($null -ne $overrideData.ServicePrincipalID) { $Config.ServicePrincipalID = $overrideData.ServicePrincipalID }
            if ($null -ne $overrideData.ServicePrincipalSecret) { $Config.ServicePrincipalSecret = $overrideData.ServicePrincipalSecret }
            if ($null -ne $overrideData.TenantID) { $Config.TenantID = $overrideData.TenantID }
            #Service Principal Changes - End

            if ($null -ne $overrideData.CredentialsOverride) { $Config.CredentialsOverride = $overrideData.CredentialsOverride }
            if ($null -ne $overrideData.CredentialsOverrideFile) { $Config.CredentialsOverrideFile = $overrideData.CredentialsOverrideFile }

            if ($null -ne $overrideData.ThrottleScanAPI) { $Config.ThrottleScanAPI = $overrideData.ThrottleScanAPI }
            if ($null -ne $overrideData.DisableScanAPI) { $Config.DisableScanAPI = $overrideData.DisableScanAPI }
            if ($null -ne $overrideData.UseOLAPDatasetConnector) { $Config.UseOLAPDatasetConnector = $overrideData.UseOLAPDatasetConnector }
        }
    }
    else {

        # Config File Missing Hint
        Write-Host "Configuration file not found. To re-run from configuration please abort and restart the scripts. Cmd: Run-PowerBIAssessment.ps1 <Config File Path>" -ForegroundColor Yellow
        Write-Host "Sample Command with config file specified:" -ForegroundColor Yellow
        Write-Host "Run-PowerBIAssessment.ps1 .\default.config." -ForegroundColor Green

        $readOutputFolder = Read-Host "Folder to put all the extracts in? (Default: out)"
        if ($readOutputFolder) { $Config.Sink = $readOutputFolder }

        $readPremium = Read-Host "Do you want to export Premium Capacity Metrics App data? [y/n] (Default: n)"
        if ($readPremium -eq "y") {
            $Config.ExportPremium = $readOutputFolder

        }
        if ($readOutputFolder) { $Config.Sink = $readOutputFolder }
    }

    $Config.AdEnvironment = @{Public = "AzureCloud"; USGov = "AzureUSGovernmentCloud"; USGovMil = "AzureUSGovernmentCloud2"; USGovHigh = "AzureUSGovernmentCloud3"; China = "AzureChinaCloud"; Germany = "AzureGermanyCloud" }[$Config.Environment]

    # Check If Service Principal Auth Enabled
    if ($Config.ServicePrincipalAuth) {
        
        $secureServicePrincipalSecret = ConvertTo-SecureString $Config.ServicePrincipalSecret -AsPlainText -Force
        $servicePrincipal = New-Object PSCredential -ArgumentList $Config.ServicePrincipalID, $secureServicePrincipalSecret 
        
        $Config.AuthContext = Connect-PowerBIServiceAccount -Environment $Config.Environment -ServicePrincipal -Credential $servicePrincipal -Tenant $Config.TenantID

        #disable what is not supported here by service principal auth
        $Config.ExportPremiumMetrics = $false
        # apparently this is working with service principal 
        # $Config.ExportTenantSettings = $false 
        $Config.ExportEmbedCodes = $false
        $Config.ExportV1Users = $false
        $Config.ExportLicenses = $false
        $Config.ExportLicensesProDetail = $false
        $Config.ExportGateways = $false

        Write-Host "Service Principal only supports activity logs and Power BI inventory exports as of now." -ForegroundColor Yellow
    }
    else {
        if ($Config.CredentialsOverride) {
            Write-Host "Applying credentials override"
            $pass = Get-Content $Config.CredentialsOverrideFile | ConvertTo-SecureString
            $credOverride = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Config.CredentialsOverride, $pass

            $Config.AuthContext = Connect-PowerBIServiceAccount -Environment $Config.Environment -Credential $credOverride
        }
        else {
            Write-Host "Waiting for user credentials..."
            # Prompt the user for credentials
            $Config.AuthContext = Connect-PowerBIServiceAccount -Environment $Config.Environment
        }
    }

    # Determine the API Gateway root Uri
    if ($Config.Environment -eq "USGov") {
        $Config.ApiGatewayUri = "https://api.powerbigov.us"
        $Config.ApiResourceUri = "https://analysis.usgovcloudapi.net"
    }
    if ($Config.Environment -eq "USGovHigh") {
        $Config.ApiGatewayUri = "https://api.high.powerbigov.us"
        $Config.ApiResourceUri = "https://high.analysis.usgovcloudapi.net"
    }
    if ($Config.Environment -eq "USGovMil") {
        $Config.ApiGatewayUri = "https://api.mil.powerbigov.us"
        $Config.ApiResourceUri = "https://mil.analysis.usgovcloudapi.net"
    }

    # Prompt the user for credentials again for Msol connection
    if ($Config.ExportV1Users -or $Config.ExportLicenses) {
        Write-Host "Waiting for user MSOL credentials..."
        if ($Config.CredentialsOverride) {
            $pass = Get-Content $Config.CredentialsOverrideFile | ConvertTo-SecureString
            $credOverride = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Config.CredentialsOverride, $pass

            $config.AuthMsolContext = Connect-MsolService -AzureEnvironment $Config.AdEnvironment -Credential $credOverride
        }
        else {
            $config.AuthMsolContext = Connect-MsolService -AzureEnvironment $Config.AdEnvironment 
        }
    }

    return $Config
}