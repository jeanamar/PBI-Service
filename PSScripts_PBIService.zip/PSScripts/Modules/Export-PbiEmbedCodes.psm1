<# 
.SYNOPSIS
Export Power BI Embed Codes

.DESCRIPTION
The sample scripts are not supported under any Microsoft standard support program or service. 
The sample scripts are provided AS IS without warranty of any kind. 
Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of 
fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the 
sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#>

function Export-PbiEmbedCodes {
    param(
        [hashtable]$Config
    )
    if ($Config.ExportEmbedCodes) {
        try {

            Write-AssessmentLog "Exporting Embed Codes..." -Config $Config
            $currentCount = 0 

            $auth_header = @{
                'Content-Type'  = 'application/json'
                'Authorization' = Get-PowerBIAccessToken -AsString
            }

            Write-Progress -Activity "Exporting Embed Codes" -Status "Records count: $($currentCount)"

            $uri_embeddedEvents = "$($Config.ApiGatewayUri)/v1.0/myorg/admin/widelySharedArtifacts/publishedToWeb"
            $queryError = $null
            $response = (Invoke-RestMethod -Uri $uri_embeddedEvents -Headers $auth_header -Method GET -ErrorVariable queryError)
            if ($null -eq $response) {
                Write-AssessmentLog "Embedded Codes pull query failed after $($currentCount) rows." -Config $Config -IsError
                Write-AssessmentLog $queryError -Config $Config
                break
            }

            $all_embeddedCodes = $response.ArtifactAccessEntities
            $continuationToken = $response.continuationToken

            while (![string]::IsNullOrEmpty($continuationToken)) {
                $uri_innerresponse = $response.continuationUri
                $response = (Invoke-RestMethod -Uri $uri_innerresponse -Headers $auth_header -Method GET)
                if ($null -eq $response) {
                    Write-AssessmentLog "Embedded Codes pull contuniation token query failed after $($currentCount) rows." -Config $Config -IsError
                    Write-AssessmentLog $queryError -Config $Config
                    break
                }
                
                $all_embeddedCodes += $response.ArtifactAccessEntities   
                $currentCount = $response.ArtifactAccessEntities.Count
                if ($currentCount -gt 0) {
                    $message = "Retrieved $($currentCount) Embed Codes"
                    Write-AssessmentLog $message -Config $Config 
                }
                $continuationToken = $response.continuationToken
            }
            $CsvObjects = @()       
            foreach ($embedCode in $all_embeddedCodes) {
                $CsvObject = [PSCustomObject]@{
                    ArtifactId        = $embedCode.artifactId 					
                    ArtifactType      = $embedCode.artifactType 
                    ArtifactName      = $embedCode.displayName
                    UserdisplayName   = $embedCode.sharer.displayName
                    UserEmailAddress  = $embedCode.sharer.emailAddress
                    UserIdentifier    = $embedCode.sharer.identifier
                    UserGraphId       = $embedCode.sharer.graphId
                    UserPrincipalType = $embedCode.sharer.principalType                    
                }
                $CsvObjects += $CsvObject
            }

            Write-Progress -Activity "Exporting Embed Codes" -Completed

            return $CsvObjects
            
        }
        catch {
            Write-AssessmentLog ($_ | Out-String) -Config $Config -IsError
        }
    }
}