function Invoke-AssessmentSQL {
    param(
        [string] $SQL,
        [hashtable]$Config
    )
    try {
        if ("SQL" -eq $Config.SinkType) {
            $con = New-Object System.Data.SqlClient.SqlConnection
            $con.ConnectionString = $Config.Sink
            $con.Open()
            $cmd = New-Object System.Data.SqlClient.SqlCommand
            $cmd.Connection = $con
            $cmd.CommandText = $sql
            $cmd.CommandTimeout = 1200

            if ($Config.LogQueries) {
                Write-AssessmentLog $sql -Config $Config -Silent
            }

            $void = $cmd.ExecuteNonQuery()
            $con.Close()
        }
        else {
            Write-AssessmentLog "Execute SQL only supported for SQL sink" -Config $Config
        }
    }
    catch {
        Write-AssessmentLog ($_ | Out-String) -Config $Config -IsError
    }  
}