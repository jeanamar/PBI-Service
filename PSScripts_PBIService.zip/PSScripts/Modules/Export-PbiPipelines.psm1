<# 
.SYNOPSIS
Export Power BI Pipelines

.DESCRIPTION
The sample scripts are not supported under any Microsoft standard support program or service. 
The sample scripts are provided AS IS without warranty of any kind. 
Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of 
fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the 
sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#>

function Export-PbiPipelines{
    param(
        [hashtable]$Config
    )

    try{
        Write-AssessmentLog "Exporting Pipelines..." -Config $Config
        $stages = @()
        $users = @()
        $batch = 0
        $batchSize = 500

        while ($True) {
            
            $skip = $batch * $batchSize
            
            $response = Invoke-PowerBIRestMethod -Method Get -Url "$($Config.ApiGatewayUri)/v1.0/myorg/admin/pipelines?`$skip=$skip&`$top=$batchSize&`$expand=stages,users" | ConvertFrom-Json    
            $all_pipelines = $response.value
            
            $totalPipelines = $all_pipelines.Count
            
            if ($totalPipelines -gt 0) {

                #Select stages from the pipeline objects
                $stages += $all_pipelines  | Select-Object @{Name = "pipelineId"; Expression = { $_.Id } }, @{Name = "pipelineDisplayName"; Expression = { $_.displayName } }, @{Name = "stages"; Expression = { $_.stages | Select-Object * } } `
                | Select-Object * -ExpandProperty stages -ExcludeProperty stages 

                $users += $all_pipelines  | Where-Object { $_.users.Count -gt 0 } `
                | Select-Object @{Name = "pipelineId"; Expression = { $_.Id } }, @{Name = "users"; Expression = { $_.users | Select-Object * } } `
                | Select-Object * -ExpandProperty users -ExcludeProperty users `

                Write-Progress -Activity "Retreiving $totalPipelines pipelines" -PercentComplete ($batch * $batchSize * 100.0 / $totalPipelines)
                $batch = $batch + 1  

            } else {
                break
            }
        }

        $stages | Select-Object @{Name = "pipelineId"; Expression = { $_.PipelineId } }, @{Name = "pipelineDisplayName"; Expression = { $_.pipelineDisplayName } } `
        | Add-AssessmentRecords -SinkContainer "Pipelines" -Config $Config

        $stages | Select-Object @{Name = "pipelineId"; Expression = { $_.PipelineId } }, @{Name = "workspaceId"; Expression = { $_.workspaceId } },   `
        @{Name = "workspaceName"; Expression = { $_.workspaceName } }, @{Name = "order"; Expression = { $_.order }}  `
        | Add-AssessmentRecords -SinkContainer "PipelineStages" -Config $Config

        $users | Add-AssessmentRecords -SinkContainer "PipelineUsers" -Config $Config
        
        Write-Progress -Activity "Exporting Pipelines" -Completed
    }
    catch{
        Write-AssessmentLog ($_ | Out-String) -Config $Config -IsError
    }
    
}