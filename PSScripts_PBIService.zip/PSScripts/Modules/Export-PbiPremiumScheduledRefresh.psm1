﻿<# 
.SYNOPSIS
Export Power BI Premium Data

.DESCRIPTION
The sample scripts are not supported under any Microsoft standard support program or service. 
The sample scripts are provided AS IS without warranty of any kind. 
Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of 
fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the 
sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#>

function Export-PbiPremiumScheduledRefresh {
    param(
        [hashtable]$Config
    )
    try {
    
        Write-Host "Exporting Refresh Schedules..."
    
        $ApiCallError = $null

        $premiumRefresh = Invoke-PowerBIRestMethod -Method Get -Url "$($Config.ApiGatewayUri)/v1.0/myorg/admin/capacities/refreshables?`$expand=capacity,group" -ErrorVariable ApiCallError | ConvertFrom-Json

        if($ApiCallError.count -gt 0){
            Write-AssessmentLog ($ApiCallError | Out-String) -Config $Config -Silent -IsError
        }

        if ($premiumRefresh.value.length -gt 0) {

            return $premiumRefresh.value | `
                Select-Object -ExcludeProperty "refreshSchedule" * `
                    , @{n = "refreshDays"; e = { $_.refreshSchedule.days -join "|" } } `
                    , @{n = "refreshTimes"; e = { $_.refreshSchedule.times -join "|" } } `
                    , @{n = "refreshEnabled"; e = { $_.refreshSchedule.enabled } } | `
                Select-Object `
                    @{Name = "id"; Expression = { $_.id } }, `
                    @{Name = "name"; Expression = { $_.name } }, `
                    @{Name = "kind"; Expression = { $_.kind } }, `
                    @{Name = "startTime"; Expression = { $_.startTime } }, `
                    @{Name = "endTime"; Expression = { $_.endTime } }, `
                    @{Name = "refreshCount"; Expression = { $_.refreshCount } }, `
                    @{Name = "refreshFailures"; Expression = { $_.refreshFailures } }, `
                    @{Name = "averageDuration"; Expression = { $_.averageDuration } }, `
                    @{Name = "medianDuration"; Expression = { $_.medianDuration } }, `
                    @{Name = "refreshesPerDay"; Expression = { $_.refreshesPerDay } }, `
                    @{Name = "refreshDays"; Expression = { $_.refreshDays } }, `
                    @{Name = "refreshTimes"; Expression = { $_.refreshTimes } }, `
                    @{Name = "refreshEnabled"; Expression = { $_.refreshEnabled } }, `
                    @{Name = "configuredBy"; Expression = { $_.configuredBy } } , `
                    @{Name = "capacity_id"; Expression = { $_.capacity.id} } , `
                    @{Name = "capacity_displayName"; Expression = { $_.capacity.displayName} } , `
                    @{Name = "group_id"; Expression = { $_.group.id } } , `
                    @{Name = "group_name"; Expression = { $_.group.name } } 
        }
        else {
            Write-AssessmentLog "No refresh schedules found" -Config $Config

            return @{id = "";name = "";kind = "";startTime = "";endTime = "";refreshCount = "";refreshFailures = "";averageDuration = "";medianDuration = "";refreshesPerDay = "";refreshSchedule = "";configuredBy = "";capacity_id = "";capacity_displayName = "";group_id = "";group_name = "";}  
        }
    }
    catch {
        Write-AssessmentLog ($_ | Out-String) -Config $Config -IsError
    }
}