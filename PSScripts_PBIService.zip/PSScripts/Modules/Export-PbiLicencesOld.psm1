<# 
.SYNOPSIS
Export Power BI Licenses

.DESCRIPTION
The sample scripts are not supported under any Microsoft standard support program or service. 
The sample scripts are provided AS IS without warranty of any kind. 
Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of 
fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the 
sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#>

function Export-PbiLicensesOld {
    param(
        [hashtable]$Config
    )

    try {

        Connect-AzureAD -AzureEnvironmentName $Config.AdEnvironment 

        Write-AssessmentLog "Exporting Licenses..." -Config $Config

        # Declare variables for export file paths, Power BI Pro service plan GUID, and current date
        $RetrieveDate = Get-Date 

        # MS Licensing Service Plan reference: https://docs.microsoft.com/en-us/azure/active-directory/users-groups-roles/licensing-service-plan-reference
        $PBIProServicePlanID = "70d33638-9c74-4d01-bfd3-562de28bd4ba"

        # Retrieve and export users
        Write-AssessmentLog "Exporting users..." -Config $Config
        $ADUsers = Get-AzureADUser -All $true | Select-Object ObjectId, CompanyName, Department, DisplayName, UserPrincipalName, UserType, @{Name = "Date Retrieved"; Expression = { $RetrieveDate } }
        $ADUsers | Add-AssessmentRecords -SinkContainer "LicensesUsers" -Config $Config

        # Retrieve and export organizational licenses : https://docs.microsoft.com/en-us/office365/enterprise/powershell/view-licenses-and-services-with-office-365-powershell
        Write-AssessmentLog "Exporting organizational licenses..." -Config $Config
        $OrgO365Licenses = Get-AzureADSubscribedSku | Select-Object SkuID, SkuPartNumber, CapabilityStatus, ConsumedUnits -ExpandProperty PrepaidUnits | `
            Select-Object SkuID, SkuPartNumber, CapabilityStatus, ConsumedUnits, Enabled, Suspended, Warning, @{Name = "Retrieve Date"; Expression = { $RetrieveDate } } 
        $OrgO365Licenses | Add-AssessmentRecords -SinkContainer "LicensesOrgO365" -Config $Config


        if ($Config.ExportLicensesProDetail) {
            Write-AssessmentLog "Exporting Licenses Pro details..." -Config $Config
		
            # Retrieve and export users with pro licenses based on Power BI Pro service plan ID ($PBIProServicePlanID). Each row represents a service plan for a particular user. This license detail is filtered to only the Power BI Pro service plan ID.
            $ProUsersCounter = 0
            $ProUsersCount = $ADUsers.Count 
            $UserLicenseDetail = @()
            $ADUsers | ForEach-Object {
                $ADUser = $_
                $UserObjectID = $ADUser.ObjectId
                if($UserObjectID -contains "43") { $UserObjectID = "error"}
                $UPN = $ADUser.UserPrincipalName
                try{
                    $UserLicenseDetail += Get-AzureADUserLicenseDetail -ObjectId $UserObjectID | `
                        Select-Object ObjectID, @{Name = "UserPrincipalName"; Expression = { $UPN } } -ExpandProperty ServicePlans
                }catch{
                    Write-AssessmentLog ($_ | Out-String) -Config $Config -IsError
                }
                $percent = [math]::round($ProUsersCounter * 100.0 / $ProUsersCount)
                Write-Progress -Activity "Retreiving users Licenses, to skip set `$ExportLicensesProDetail to false and rerun the script" -Status "$percent% complete" -PercentComplete $percent
                $ProUsersCounter += 1
            }
            $ProUsers = $UserLicenseDetail | Where-Object { $_.ServicePlanId -eq $PBIProServicePlanID }
            $ProUsers | Add-AssessmentRecords -SinkContainer "LicensesUsersPro" -Config $Config
        }
        else {
            Write-AssessmentLog "Export Licenses Pro details skipped" -Config $Config
        }
    }
    catch {
        Write-AssessmentLog ($_ | Out-String) -Config $Config -IsError
    }
}