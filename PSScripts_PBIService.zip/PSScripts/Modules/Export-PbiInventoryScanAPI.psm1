﻿<# 
.SYNOPSIS
Export Power BI Inventory

.DESCRIPTION
The sample scripts are not supported under any Microsoft standard support program or service. 
The sample scripts are provided AS IS without warranty of any kind. 
Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of 
fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the 
sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#>

function Export-PbiInventoryScanAPI {
    param(
        [hashtable]$Config
    )
   

    Write-AssessmentLog "Exporting Inventory via the Scan API..." -Config $Config

    $workspaces = @()
    $datasets = @()
    $datasources = @()
    $dashboards = @()
    $reports = @()
    $users = @()
    $dataflows = @()
        
    $skip = 0
    $batch = 0
    $batchSize = 100
    $batchTimeout = 600
    $allWorkspaces = Invoke-PowerBIRestMethod -Method Get -Url "$($Config.ApiGatewayUri)/v1.0/myorg/admin/workspaces/modified" | ConvertFrom-Json

    while ($True) {
        $skip = $batch * $batchSize

        $workspaceArray = $allWorkspaces | Select-Object -ExpandProperty Id -Skip $skip -First $batchSize
        $scanList = @{ workspaces = $workspaceArray }
                
        if ($workspaceArray.Count -gt 0) {
            try {
                $inventoryQuery = "lineage=true&datasourceDetails=true&getArtifactUsers=true"
                if($Config.ExportInventoryExpressions){
                    $inventoryQuery += "&datasetSchema=true&datasetExpressions=true"
                }
                $scan = Invoke-PowerBIRestMethod -Method Post -Url "$($Config.ApiGatewayUri)/v1.0/myorg/admin/workspaces/getInfo?$inventoryQuery"-Body ($scanList | ConvertTo-Json) | ConvertFrom-Json
            
                Write-AssessmentLog "Scan started at $($scan.createdDateTime) for $($workspaceArray.Count) workspace(s)" -Config $Config
                $timeRemaining = $batchTimeout

                if ($Config.ThrottleScanAPI) {
                    Start-Sleep -Seconds 7
                }
            
                $waitForScanToComplete = $True
                while ($waitForScanToComplete) {

                    $ApiCallError = $null
                    
                    $status = Invoke-PowerBIRestMethod -Method Get -Url "$($Config.ApiGatewayUri)/v1.0/myorg/admin/workspaces/scanStatus/$($scan.id)" -ErrorVariable ApiCallError | ConvertFrom-Json
                    
                    if($ApiCallError.count -gt 0){
                        Write-AssessmentLog ($ApiCallError | Out-String) -Config $Config -Silent -IsError
                    }
                    
                    if ($status.status -eq "Succeeded") {
                        break
                    }
                    if ($timeRemaining -lt 0) {
                        Write-AssessmentLog "Scan timed out. Last status: $($status.status)" -Config $Config -IsError
                        break
                    }
                    Start-Sleep -Seconds 2
                }

                $scanResult = Invoke-PowerBIRestMethod -Method Get -Url "$($Config.ApiGatewayUri)/v1.0/myorg/admin/workspaces/scanResult/$($scan.id)" | ConvertFrom-Json

                $scanResult.workspaces | ForEach-Object {
                    $currentWorkspace = $_
                    $workspaces += $currentWorkspace | Select-Object * -ExcludeProperty @("reports", "dashboards", "datasets", "dataflows")   
                
                    $reports += $currentWorkspace.reports | Select-Object *, @{Name = "workspaceId"; Expression = { $currentWorkspace.Id } }

                    $dashboards += $currentWorkspace.dashboards | Select-Object *, @{Name = "workspaceId"; Expression = { $currentWorkspace.Id } }

                    $datasets += $currentWorkspace.datasets | Select-Object *, @{Name = "workspaceId"; Expression = { $currentWorkspace.Id } }

                    $dataflows += $currentWorkspace.dataflows | Select-Object *, @{Name = "workspaceId"; Expression = { $currentWorkspace.Id } }
                }        

                $datasources += $scanResult.datasourceInstances
            }
            catch {
                Write-AssessmentLog ($_ | Out-String) -Config $Config -IsError
            }  
            Write-Progress -Activity "Retreiving $($allWorkspaces.Count) workspaces" -PercentComplete ($batch * $batchSize * 100.0 / $allWorkspaces.Count)
            $batch = $batch + 1            
        }
        else {
            break
        }
    }        
    
    #Get workspace users
    $batch = 0
    $batchSize = 500
    while ($True) {
        $skip = $batch * $batchSize
        try {
            $workspaceBatch = Invoke-PowerBIRestMethod -Method Get  -Url "$($Config.ApiGatewayUri)/v1.0/myorg/admin/groups?`$skip=$skip&`$top=$batchSize&`$expand=users" | ConvertFrom-Json        
            $totalWorkspaces = $workspaceBatch.'@odata.count'
        }
        catch {
            Write-AssessmentLog ($_ | Out-String) -Config $Config -IsError
        }    
        if ($workspaceBatch.value.Count -gt 0) {
            #Select workspace users from the workspace objects
            $users += $workspaceBatch.value | Where-Object { $_.users.Count -gt 0 } `
            | Select-Object @{Name = "workspaceId"; Expression = { $_.Id } }, @{Name = "users"; Expression = { $_.users | Select-Object * -ExcludeProperty WorkspaceId } } `
            | Select-Object * -ExpandProperty users -ExcludeProperty users

            Write-Progress -Activity "Retreiving users for $totalWorkspaces workspaces" -PercentComplete ($batch * $batchSize * 100.0 / $totalWorkspaces)
            $batch = $batch + 1            
        }
        else {
            break
        }
        
    }     

    #save all of the workspaces in use in the organization
    $workspaces | Select-Object -ExcludeProperty "Users" *, @{n = "Users"; e = { if ($_.Users) { $_.Users | ConvertTo-Csv -NoTypeInformation -Delimiter ":" | Out-String } else { "" } } } `
    | Select-Object @{Name = "Id"; Expression = { $_.Id } }, `
    @{Name = "Name"; Expression = { $_.Name } }, `
    @{Name = "IsReadOnly"; Expression = { $_.IsReadOnly } }, `
    @{Name = "IsOnDedicatedCapacity"; Expression = { $_.IsOnDedicatedCapacity } }, `
    @{Name = "CapacityId"; Expression = { $_.CapacityId } }, `
    @{Name = "Description"; Expression = { $_.Description } }, `
    @{Name = "Type"; Expression = { $_.Type } }, `
    @{Name = "State"; Expression = { $_.State } }, `
    @{Name = "IsOrphaned"; Expression = { [string]::IsNullOrEmpty($_.Users) } }, `
    @{Name = "Users"; Expression = { $_.Users } } `
    | Add-AssessmentRecords -SinkContainer "Workspaces" -Config $Config


    if ($Config.ExportV1Users) {
        $v1Workspaces = $workspaces | Where-Object { $_.Type -eq "Group" }
        $totalV1Workspaces = $v1Workspaces.Count        
        $workspaceCounter = 0
        $pref = $ErrorActionPreference
        $ErrorActionPreference = "silentlycontinue"
        $v1Workspaces | ForEach-Object {   
            $currentWorkspaceId = $_.Id
                
            $members = Get-AzureADGroupMember -ObjectId $currentWorkspaceId -ErrorAction SilentlyContinue 2>$null

            $users += $members | Select-Object `
            @{Name = "workspaceId"; Expression = { $currentWorkspaceId } }, `
            @{Name = "emailAddress"; Expression = { $_.userPrincipalName } }, `
            @{Name = "groupUserAccessRight"; Expression = { $_.UserType } }, `
            @{Name = "identifier"; Expression = { $_.userPrincipalName } }, `
            @{Name = "displayName"; Expression = { $_.displayName } }, `
            @{Name = "principalType"; Expression = { "User" } }

            Write-Progress -Activity "Retreiving users from $totalV1Workspaces v1 workspaces. To skip this step, set `$ExportV1Users to `$False and rerun the script" -PercentComplete ($workspaceCounter * 100.0 / $totalV1Workspaces)
            $workspaceCounter += 1
        } 
        $ErrorActionPreference = $pref
    }
    else {
        Write-AssessmentLog "ExportV1Users is False. Skipping..." -Config $Config
    }

    #save all of the workspace users in the organization
    $users | Select-Object @{Name = "workspaceId"; Expression = { $_.workspaceId } }, `
    @{Name = "emailAddress"; Expression = { $_.emailAddress } }, `
    @{Name = "groupUserAccessRight"; Expression = { $_.groupUserAccessRight } }, `
    @{Name = "identifier"; Expression = { $_.identifier } }, `
    @{Name = "principalType"; Expression = { $_.principalType } }, `
    @{Name = "displayName"; Expression = { $_.displayName } } `
    | Add-AssessmentRecords -SinkContainer "Users" -Config $Config

    #save all of the datasets in use in the organization
    $datasets | Select-Object @{Name = "Id"; Expression = { $_.Id } }, `
    @{Name = "Name"; Expression = { $_.Name } }, `
    @{Name = "ConfiguredBy"; Expression = { $_.ConfiguredBy } }, `
    @{Name = "CreatedDate"; Expression = { $_.CreatedDate } }, `
    @{Name = "TargetStorageMode"; Expression = { $_.TargetStorageMode } }, `
    @{Name = "ContentProviderType"; Expression = { $_.ContentProviderType } }, `
    @{Name = "WorkspaceId"; Expression = { $_.WorkspaceId } }, `
    @{Name = "DatasourceUsages"; Expression = { if ($_.datasourceUsages -and $_.datasourceUsages.datasourceInstanceId) { [string]::Join(",", $_.datasourceUsages.datasourceInstanceId) } else { "" } } } `
    | Add-AssessmentRecords -SinkContainer "Datasets" -Config $Config

    if($Config.ExportInventoryExpressions){
        $datasets | Select-Object -ExpandProperty tables @{Name = "DatasetId"; Expression = {$_.Id}} `
        | Select-Object DatasetId, name, isHidden, `
            @{Name = "source"; Expression = {$_.source | ConvertTo-Json}}, `
            @{Name = "measures"; Expression = {$_.measures | ConvertTo-Json}}, `
            @{Name = "columns"; Expression = {$_.columns | ConvertTo-Json}} `
        | Add-AssessmentRecords -SinkContainer "DatasetTables" -Config $Config
    }

    $dataflows | Select-Object @{Name = "Id"; Expression = { $_.objectId } }, `
    @{Name = "Name"; Expression = { $_.name } }, `
    @{Name = "ConfiguredBy"; Expression = { $_.configuredBy } }, `
    @{Name = "Description"; Expression = { $_.description } }, `
    @{Name = "ModelUrl"; Expression = { $_.modelUrl } }, `
    @{Name = "ModifiedBy"; Expression = { $_.modifiedBy } }, `
    @{Name = "ModifiedDateTime"; Expression = { $_.modifiedDateTime } }, `
    @{Name = "WorkspaceId"; Expression = { $_.WorkspaceId } }, `
    @{Name = "DatasourceUsages"; Expression = { if ($_.datasourceUsages -and $_.datasourceUsages.datasourceInstanceId) { [string]::Join(",", $_.datasourceUsages.datasourceInstanceId) } else { "" } } } `
    | Add-AssessmentRecords -SinkContainer "Dataflows" -Config $Config
        
    $dashboards | Select-Object @{Name = "Id"; Expression = { $_.Id } }, `
    @{Name = "displayName"; Expression = { $_.displayName } }, `
    @{Name = "IsReadOnly"; Expression = { $_.IsReadOnly } }, `
    @{Name = "EmbedUrl"; Expression = { $_.EmbedUrl } }, `
    @{Name = "WorkspaceId"; Expression = { $_.WorkspaceId } } `
    | Add-AssessmentRecords -SinkContainer "Dashboards" -Config $Config

    $reports | Select-Object @{Name = "Id"; Expression = { $_.Id } }, `
    @{Name = "ReportType"; Expression = { $_.ReportType } }, `
    @{Name = "Name"; Expression = { $_.Name } }, `
    @{Name = "DatasetId"; Expression = { $_.DatasetId } }, `
    @{Name = "WorkspaceId"; Expression = { $_.WorkspaceId } } `
    | Add-AssessmentRecords -SinkContainer "Reports" -Config $Config

    $datasources | Select-Object @{Name = "DatasourceType"; Expression = { $_.DatasourceType } }, `
    @{Name = "ConnectionDetails"; Expression = { $_.ConnectionDetails | ConvertTo-Json} }, `
    @{Name = "GatewayId"; Expression = { $_.GatewayId } }, `
    @{Name = "DatasourceId"; Expression = { $_.DatasourceId } } `
    | Add-AssessmentRecords -SinkContainer "Datasources" -Config $Config

    if ($Config.ExportRefreshes) {
        $TopN = 50
        $hists = @()

        $totalDatasets = $datasets.Count
        $datasetIndex = 0
        $datasets | ForEach-Object { 
            $hist = New-Object PSObject
            $hist = Invoke-PowerBIRestMethod -Method Get -Url "$($Config.ApiGatewayUri)/v1.0/myorg/groups/$($PSItem.workspaceId)/datasets/$($PSItem.id)/refreshes/?`$top=$($TopN)" -ErrorAction SilentlyContinue | ConvertFrom-Json
            if ($hist) {
                $hist.value | Add-Member -NotePropertyName "DatasetID" -NotePropertyValue $PSItem.id
                $hist.value | Add-Member -NotePropertyName "DatasetName" -NotePropertyValue $PSItem.name
                $hist.value | Add-Member -NotePropertyName "WorkspaceID" -NotePropertyValue $PSItem.workspaceId
            }
            $hists += $hist
            $datasetIndex += 1
            Write-Progress -Activity "Retreiving refresh history for $totalDatasets datasets. To skip this step, set ExportRefreshes to `$False and rerun the script" -PercentComplete ($datasetIndex * 100.0 / $totalDatasets)
        }
          
        $hists.value | Select-Object @{Name = "id"; Expression = { $_.id } }, `
        @{Name = "refreshType"; Expression = { $_.refreshType } }, `
        @{Name = "startTime"; Expression = { $_.startTime } }, `
        @{Name = "endTime"; Expression = { $_.endTime } }, `
        @{Name = "serviceExceptionJson"; Expression = { $_.serviceExceptionJson } }, `
        @{Name = "status"; Expression = { $_.status } }, `
        @{Name = "DatasetID"; Expression = { $_.DatasetID } }, `
        @{Name = "WorkspaceID"; Expression = { $_.WorkspaceID } }, `
        @{Name = "DatasetName"; Expression = { $_.DatasetName } } `
        | Add-AssessmentRecords -SinkContainer "RefreshHistory" -Config $Config
        
    }
    else {
        Write-AssessmentLog "ExportRefreshes is False. Skipping..." -Config $Config
    }

}