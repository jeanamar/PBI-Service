﻿<# 
.SYNOPSIS
Export Power BI Premium Data

.DESCRIPTION
The sample scripts are not supported under any Microsoft standard support program or service. 
The sample scripts are provided AS IS without warranty of any kind. 
Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of 
fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of 
the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the 
sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 
#>

function Export-PbiPremiumData {
    param(
        [string]$DAXQuery,
        [hashtable]$Config
    )

    try {
        if($Config.UseOLAPDatasetConnector){
            $clusterResponse = Invoke-PowerBIRestMethod -Method Get -Url "$($Config.ApiGatewayUri)/metadata/cluster" | ConvertFrom-Json
            $clusterUri = $clusterResponse.backendUrl
        
            $tokenOnly = (Get-PowerBIAccessToken -AsString).Replace("Bearer ", "")
            $resourceUri = $Config.ApiResourceUri.Replace("https", "pbiazure")
            $datasetId = $Config.PremiumDatasetId
            $cs = "Provider=MSOLAP;Data Source=$resourceUri/powerbi/api;Identity Provider=https://login.microsoftonline.com/common, $($Config.ApiResourceUri)/powerbi/api, $datasetId;Initial Catalog=$datasetId;Location=" + $clusterUri + "xmla?vs=sobe_wowvirtualserver&db=$datasetId;Password=$tokenOnly"
            $connection = New-Object System.Data.OleDb.OleDbConnection $cs
            $connection.Open()
            $command = New-Object System.Data.OleDb.OleDbCommand -ArgumentList $DAXQuery, $connection
            $command.CommandTimeout = 1200; 
            $rdr = $command.ExecuteReader()
            $result = New-Object System.Collections.ArrayList
            While ($rdr.Read()) {
                $properties = @{}
                For ($fieldIndex = 0; $fieldIndex -lt $rdr.FieldCount; $fieldIndex++) {
                    $properties[$rdr.GetName($fieldIndex)] = $rdr[$fieldIndex]
                }
                $row = New-Object PSObject -Property $properties
                $result.Add($row) > $null
            }
            $rdr.Close()
            $connection.Close()        
            return $result 
        
        }else{
            $queryList =  @( [pscustomobject]@{query=$DAXQuery})
            $queryParam = @{ queries = $queryList }
            $ApiCallError = $null
            $queryResponse = Invoke-PowerBIRestMethod -Method Post -Url "$($Config.ApiGatewayUri)/v1.0/myorg/datasets/$($Config.PremiumDatasetId)/executeQueries" -Body ($queryParam | ConvertTo-Json) -ErrorVariable ApiCallError | ConvertFrom-Json
            if($ApiCallError.count -eq 0){
                return $queryResponse.results[0].tables[0].rows 
            }else{
                Write-AssessmentLog ($ApiCallError | Out-String) -Config $Config -Silent -IsError
                Write-AssessmentLog "Last query: $DAXQuery" -Config $Config -Silent
            }
        }
    }
    catch {
        Write-AssessmentLog ($_ | Out-String) -Config $Config -IsError
    }
}