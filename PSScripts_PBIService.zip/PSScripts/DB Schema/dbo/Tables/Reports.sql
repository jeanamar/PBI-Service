﻿CREATE TABLE [dbo].[Reports] (
    [Tag]         NVARCHAR (20)    NULL,
    [Id]          UNIQUEIDENTIFIER NULL,
    [ReportType]  NVARCHAR (20)    NULL,
    [Name]        NVARCHAR (1000)  NULL,
    [DatasetId]   UNIQUEIDENTIFIER NULL,
    [WorkspaceId] UNIQUEIDENTIFIER NULL
);



