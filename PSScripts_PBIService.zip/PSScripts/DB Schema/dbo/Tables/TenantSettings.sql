﻿CREATE TABLE [dbo].[TenantSettings] (
    [Tag]                   NVARCHAR (20)   NULL,
    [switchName]            NVARCHAR (1000) NULL,
    [switchId]              NVARCHAR (1000) NULL,
    [deniedSecurityGroups]  NVARCHAR (MAX)  NULL,
    [allowedSecurityGroups] NVARCHAR (MAX)  NULL,
    [isGranular]            BIT             NULL,
    [isEnabled]             BIT             NULL
);



