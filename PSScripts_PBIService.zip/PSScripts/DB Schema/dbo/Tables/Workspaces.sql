﻿CREATE TABLE [dbo].[Workspaces] (
    [Tag]                   NVARCHAR (20)    NULL,
    [Id]                    UNIQUEIDENTIFIER NULL,
    [Name]                  NVARCHAR (MAX)   NULL,
    [IsReadOnly]            BIT              NULL,
    [IsOnDedicatedCapacity] BIT              NULL,
    [CapacityId]            UNIQUEIDENTIFIER NULL,
    [Description]           NVARCHAR (MAX)   NULL,
    [Type]                  NVARCHAR (20)    NULL,
    [State]                 NVARCHAR (10)    NULL,
    [IsOrphaned]            BIT              NULL,
    [Users]                 NVARCHAR (MAX)   NULL
);



