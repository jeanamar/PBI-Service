﻿CREATE TABLE [dbo].[Datasets] (
    [Tag]                 NVARCHAR (20)    NULL,
    [Id]                  UNIQUEIDENTIFIER NULL,
    [Name]                NVARCHAR (1000)  NULL,
    [ConfiguredBy]        NVARCHAR (1024)  NULL,
    [CreatedDate]         DATETIME         NULL,
    [TargetStorageMode]   NVARCHAR (20)    NULL,
    [ContentProviderType] NVARCHAR (40)    NULL,
    [WorkspaceId]         UNIQUEIDENTIFIER NULL,
    [DatasourceUsages]    NVARCHAR (MAX)   NULL
);



