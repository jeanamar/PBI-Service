﻿CREATE TABLE [dbo].[PremiumCapacities] (
    [Tag]                     NVARCHAR (20)    NULL,
    [id]                      UNIQUEIDENTIFIER NULL,
    [displayName]             NVARCHAR (1000)  NULL,
    [sku]                     NVARCHAR (20)    NULL,
    [state]                   NVARCHAR (20)    NULL,
    [region]                  NVARCHAR (20)    NULL,
    [capacityUserAccessRight] NVARCHAR (20)    NULL,
    [admins]                  NVARCHAR (MAX)   NULL
);



