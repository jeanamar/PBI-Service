﻿CREATE TABLE [dbo].[RefreshHistory] (
    [Tag]                  NVARCHAR (20)    NULL,
    [refreshType]          NVARCHAR (20)    NULL,
    [id]                   INT NULL,
    [serviceExceptionJson] NVARCHAR (MAX)   NULL,
    [DatasetName]          NVARCHAR (1000)  NULL,
    [WorkspaceID]          UNIQUEIDENTIFIER NULL,
    [status]               NVARCHAR (20)    NULL,
    [startTime]            DATETIME         NULL,
    [endTime]              DATETIME         NULL,
    [DatasetID]            UNIQUEIDENTIFIER NULL
);



