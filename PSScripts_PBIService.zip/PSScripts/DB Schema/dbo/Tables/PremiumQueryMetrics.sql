﻿CREATE TABLE [dbo].[PremiumQueryMetrics] (
    [Tag]                           NVARCHAR (20)    NULL,
    [QueryMetrics.timestamp]        DATETIME         NULL,
    [QueryMetrics.capacityObjectId] UNIQUEIDENTIFIER NULL,
    [QueryMetrics.datasetId]        UNIQUEIDENTIFIER NULL,
    [SumtotalHighWaitCount]         INT              NULL,
    [SumtotalWaitCount]             INT              NULL,
    [SummaxWaitTime]                FLOAT              NULL,
    [SummaxDuration]                FLOAT              NULL,
    [SummaxCPUTime]                 FLOAT              NULL,
    [SumaverageWaitTime]            FLOAT              NULL,
    [SumaverageDuration]            FLOAT              NULL,
    [SumaverageCPUTime]             FLOAT              NULL
);



