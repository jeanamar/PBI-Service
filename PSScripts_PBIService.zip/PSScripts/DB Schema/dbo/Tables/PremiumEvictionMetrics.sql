﻿CREATE TABLE [dbo].[PremiumEvictionMetrics] (
    [Tag]                                           NVARCHAR (20)    NULL,
    [EvictionMetrics.capacityObjectId]              UNIQUEIDENTIFIER NULL,
    [EvictionMetrics.timestamp]                     DATETIME         NULL,
    [EvictionMetrics.activeModelCount]              INT              NULL,
    [EvictionMetrics.inactiveModelCount]            INT              NULL,
    [EvictionMetrics.averageIdleTimeBeforeEviction] INT              NULL
);



