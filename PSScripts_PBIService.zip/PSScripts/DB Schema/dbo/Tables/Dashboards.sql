﻿CREATE TABLE [dbo].[Dashboards] (
    [Tag]         NVARCHAR (20)    NULL,
    [Id]          UNIQUEIDENTIFIER NULL,
    [displayName] NVARCHAR (1000)  NULL,
    [IsReadOnly]  BIT              NULL,
    [EmbedUrl]    NVARCHAR (MAX)   NULL,
    [WorkspaceId] UNIQUEIDENTIFIER NULL
);



