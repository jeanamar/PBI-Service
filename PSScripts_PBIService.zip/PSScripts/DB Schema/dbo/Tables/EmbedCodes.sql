﻿CREATE TABLE [dbo].[EmbedCodes] (
    [Tag]               NVARCHAR (20)   NULL,
    [snapshotName]      NVARCHAR (100)  NULL,
    [workspaceName]     NVARCHAR (1000) NULL,
    [publisherUserName] NVARCHAR (1024) NULL,
    [disabledByUser]    NVARCHAR (1024) NULL,
    [createDate]        DATETIME        NULL,
    [lastRefreshTime]   DATETIME        NULL
);



