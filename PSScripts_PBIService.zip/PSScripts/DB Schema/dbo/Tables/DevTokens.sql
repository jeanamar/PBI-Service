﻿CREATE TABLE [dbo].[DevTokens] (
    [Tag]   NVARCHAR (20) NULL,
    [usage] FLOAT (53)    NULL
);



