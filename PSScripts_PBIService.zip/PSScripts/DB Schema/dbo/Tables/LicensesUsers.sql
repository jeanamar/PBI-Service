﻿CREATE TABLE [dbo].[LicensesUsers] (
    [Tag]               NVARCHAR (20)    NULL,
    [ObjectId]          UNIQUEIDENTIFIER NULL,
    [CompanyName]       NVARCHAR (1000)  NULL,
    [Department]        NVARCHAR (1000)  NULL,
    [DisplayName]       NVARCHAR (1000)  NULL,
    [UserPrincipalName] NVARCHAR (1024)  NULL,
    [UserType]          NVARCHAR (20)    NULL,
    [Date Retrieved]    DATETIME         NULL
);



