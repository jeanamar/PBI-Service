﻿CREATE TABLE [dbo].[PremiumSystemMetrics] (
    [Tag]                                   NVARCHAR (20)    NULL,
    [SystemMetrics.capacityObjectId]        UNIQUEIDENTIFIER NULL,
    [SystemMetrics.Timestamp]               DATETIME         NULL,
    [SystemMemoryConsumptionInGB]           FLOAT (53)       NULL,
    [DatasetsMemoryConsumptionInGB]         FLOAT (53)       NULL,
    [DataflowsMemoryConsumptionInGB]        FLOAT (53)       NULL,
    [PaginatedReportsMemoryConsumptionInGB] FLOAT (53)       NULL,
    [DatasetsCPUConsumption]                INT              NULL,
    [DataflowsCPUConsumption]               INT              NULL,
    [PaginatedReportsCPUConsumption]        INT              NULL,
    [SystemCPUConsumption]                  INT              NULL
);



