﻿CREATE TABLE [dbo].[PremiumArtifactMetrics] (
    [Tag]                                                 NVARCHAR (20)    NULL,
    [Artifacts.ArtifactKind]                              NVARCHAR (20)    NULL,
    [Artifacts.ArtifactId]                                UNIQUEIDENTIFIER NULL,
    [Metrics_by_Artifact_and_Operation_and_Hour.DateTime] DATETIME         NULL,
    [Operation Names.OperationName]                       NVARCHAR (1000)  NULL,
    [OperationsCount]                                     INT              NULL,
    [UsersCount]                                          INT              NULL,
    [CPU (ms)]                                            INT              NULL,
    [Duration (ms)]                                       INT              NULL
);



