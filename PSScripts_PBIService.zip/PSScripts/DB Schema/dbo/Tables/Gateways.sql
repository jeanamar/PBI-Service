﻿CREATE TABLE [dbo].[Gateways] (
    [Tag]                    NVARCHAR (20)    NULL,
    [clusterId]              UNIQUEIDENTIFIER NULL,
    [clusterName]            NVARCHAR (1000)  NULL,
    [type]                   NVARCHAR (20)    NULL,
    [cloudDatasourceRefresh] BIT              NULL,
    [customConnectors]       BIT              NULL,
    [version]                NVARCHAR (20)    NULL,
    [status]                 NVARCHAR (20)    NULL,
    [versionStatus]          NVARCHAR (20)    NULL,
    [contactInformation]     NVARCHAR (1024)  NULL,
    [machine]                NVARCHAR (1000)  NULL,
    [nodeId]                 UNIQUEIDENTIFIER NULL
);



