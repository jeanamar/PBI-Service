﻿CREATE TABLE [dbo].[PremiumRefresh] (
    [Tag]             NVARCHAR (20)    NULL,
    [id]              UNIQUEIDENTIFIER NULL,
    [name]            NVARCHAR (1000)  NULL,
    [kind]            NVARCHAR (20)    NULL,
    [startTime]       DATETIME         NULL,
    [endTime]         DATETIME         NULL,
    [refreshCount]    INT              NULL,
    [refreshFailures] INT              NULL,
    [averageDuration] FLOAT              NULL,
    [medianDuration]  FLOAT              NULL,
    [refreshesPerDay] INT              NULL,
    [refreshDays]     NVARCHAR (2000)  NULL,
    [refreshTimes]    NVARCHAR (2000)  NULL,
    [refreshEnabled]  BIT              NULL,
    [configuredBy]    NVARCHAR (1024)  NULL
);



