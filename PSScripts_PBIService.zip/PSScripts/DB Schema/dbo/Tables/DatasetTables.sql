﻿CREATE TABLE [dbo].[Datasets] (
    [Tag]                 NVARCHAR (20)    NULL,
    [DatasetId]           UNIQUEIDENTIFIER NULL,
    [Name]                NVARCHAR (1000)  NULL,
    [IsHidden]            BIT  NULL,
    [Source]              NTEXT         NULL,
    [Measures]            NTEXT         NULL,
    [Columns]             NTEXT         NULL
);



