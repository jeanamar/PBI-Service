﻿CREATE TABLE [dbo].[Users] (
    [Tag]                  NVARCHAR (20)    NULL,
    [workspaceId]          UNIQUEIDENTIFIER NULL,
    [emailAddress]         NVARCHAR (1024)  NULL,
    [groupUserAccessRight] NVARCHAR (20)    NULL,
    [identifier]           NVARCHAR (1024)  NULL,
    [principalType]        NVARCHAR (20)    NULL,
    [displayName]          NVARCHAR (1000)  NULL
);



