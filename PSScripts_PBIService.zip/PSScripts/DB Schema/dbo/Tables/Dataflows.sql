﻿CREATE TABLE [dbo].[Dataflows] (
    [Tag]              NVARCHAR (20)    NULL,
    [Id]               UNIQUEIDENTIFIER NULL,
    [Name]             NVARCHAR (1000)  NULL,
    [ConfiguredBy]     NVARCHAR (MAX)   NULL,
    [Description]      NVARCHAR (MAX)   NULL,
    [ModelUrl]         NVARCHAR (MAX)   NULL,
    [ModifiedBy]       NVARCHAR (1024)  NULL,
    [ModifiedDateTime] DATETIME         NULL,
    [WorkspaceId]      UNIQUEIDENTIFIER NULL,
    [DatasourceUsages] NVARCHAR (MAX)   NULL
);



