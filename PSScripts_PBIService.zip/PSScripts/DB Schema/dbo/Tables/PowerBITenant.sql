﻿CREATE TABLE [dbo].[PowerBITenant] (
    [Tag]          NVARCHAR (20)   NULL,
    [TenantDomain] NVARCHAR (1000) NULL
);



