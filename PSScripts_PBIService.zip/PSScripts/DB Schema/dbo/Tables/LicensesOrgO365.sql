﻿CREATE TABLE [dbo].[LicensesOrgO365] (
    [Tag]              NVARCHAR (20)    NULL,
    [SkuId]            UNIQUEIDENTIFIER NULL,
    [SkuPartNumber]    NVARCHAR (1000)  NULL,
    [CapabilityStatus] NVARCHAR (20)    NULL,
    [ConsumedUnits]    INT              NULL,
    [Enabled]          INT              NULL,
    [Suspended]        INT              NULL,
    [Warning]          INT              NULL,
    [Retrieve Date]    DATETIME         NULL
);



