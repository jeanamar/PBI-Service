﻿CREATE TABLE [dbo].[PremiumDatasetInfo] (
    [Tag]                     NVARCHAR (20)    NULL,
    [DatasetInfo.id]          UNIQUEIDENTIFIER NULL,
    [DatasetInfo.datasetName] NVARCHAR (1000)  NULL,
    [DatasetInfo.workspaceId] UNIQUEIDENTIFIER NULL
);



