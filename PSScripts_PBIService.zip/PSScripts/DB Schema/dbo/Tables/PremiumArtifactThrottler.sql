﻿CREATE TABLE [dbo].[PremiumArtifactThrottler] (
    [Tag]                                               NVARCHAR (20)    NULL,
    [Artifacts.ArtifactKind]                            NVARCHAR (20)    NULL,
    [Artifacts.ArtifactId]                              UNIQUEIDENTIFIER NULL,
    [Throttler_by_Artifact_and_Hour.HourStart]          DATETIME         NULL,
    [Throttler_by_Artifact_and_Hour.OperationStartTime] DATETIME         NULL,
    [CPU (ms)]                                          INT              NULL
);



