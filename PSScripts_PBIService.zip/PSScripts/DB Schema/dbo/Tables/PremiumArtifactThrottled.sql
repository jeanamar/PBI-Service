﻿CREATE TABLE [dbo].[PremiumArtifactThrottled] (
    [Tag]                                                NVARCHAR (20)    NULL,
    [Artifacts (Throttled).ArtifactKind]                 NVARCHAR (20)    NULL,
    [Artifacts (Throttled).ArtifactId]                   UNIQUEIDENTIFIER NULL,
    [Throttled_by_Artifact_and_Hour.HourStart]           DATETIME         NULL,
    [Throttled_by_Artifact_and_Hour.OperationStartTime]  DATETIME         NULL,
    [Throttled_by_Artifact_and_Hour.ThrottleTime]        INT              NULL,
    [Throttled_by_Artifact_and_Hour.ThrottledOperations] INT              NULL,
    [UserCount]                                          INT              NULL
);



