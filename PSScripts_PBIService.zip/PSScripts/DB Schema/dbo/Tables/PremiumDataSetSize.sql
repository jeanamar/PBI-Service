﻿CREATE TABLE [dbo].[PremiumDataSetSize] (
    [Tag]                         NVARCHAR (20)    NULL,
    [DatasetSize.datasetId]       UNIQUEIDENTIFIER NULL,
    [DatasetSize.timestamp]       DATETIME         NULL,
    [datasetSizeInMB]             INT              NULL,
    [ActiveDatasetsCountComputed] INT              NULL
);



