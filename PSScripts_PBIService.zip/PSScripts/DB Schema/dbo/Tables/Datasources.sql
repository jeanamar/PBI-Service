﻿CREATE TABLE [dbo].[Datasources] (
    [Tag]               NVARCHAR (20)    NULL,
    [DatasourceType]    NVARCHAR (20)    NULL,
    [ConnectionDetails] NVARCHAR (MAX)   NULL,
    [GatewayId]         UNIQUEIDENTIFIER NULL,
    [DatasourceId]      UNIQUEIDENTIFIER NULL
);



