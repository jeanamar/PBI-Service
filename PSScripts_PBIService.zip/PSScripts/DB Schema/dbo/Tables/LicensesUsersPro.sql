﻿CREATE TABLE [dbo].[LicensesUsersPro] (
    [Tag]                NVARCHAR (20)    NULL,
    [ObjectId]           NVARCHAR (1000)  NULL,
    [UserPrincipalName]  NVARCHAR (1024)  NULL,
    [AppliesTo]          NVARCHAR (20)    NULL,
    [ProvisioningStatus] NVARCHAR (20)    NULL,
    [ServicePlanId]      UNIQUEIDENTIFIER NULL,
    [ServicePlanName]    NVARCHAR (100)   NULL
);



