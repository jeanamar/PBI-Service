﻿CREATE TABLE [dbo].[PremiumUtilization] (
    [Tag]                        NVARCHAR (20)    NULL,
    [Detail.ExecutingUser]       NVARCHAR (1024)  NULL,
    [Detail.WorkspaceName]       NVARCHAR (1000)  NULL,
    [Detail.UtilizationType]     NVARCHAR (20)    NULL,
    [Detail.User]                NVARCHAR (1024)  NULL,
    [Detail.ArtifactId]          UNIQUEIDENTIFIER NULL,
    [Detail.PremiumCapacityId]   UNIQUEIDENTIFIER NULL,
    [Detail.OperationName]       NVARCHAR (1000)  NULL,
    [SumCpuTimeMs]               INT              NULL,
    [Detail.Status]              NVARCHAR (20)    NULL,
    [Detail.OperationStartDate]  DATETIME         NULL,
    [Detail.ArtifactName]        NVARCHAR (1000)  NULL,
    [SumDurationMs]              INT              NULL,
    [Detail.WorkspaceId]         UNIQUEIDENTIFIER NULL,
    [Detail.PremiumCapacitySku]  NVARCHAR (20)    NULL,
    [Detail.PremiumCapacityName] NVARCHAR (1000)  NULL,
    [Detail.OperationStartTime]  DATETIME         NULL
);


